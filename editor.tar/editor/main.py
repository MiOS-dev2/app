import tkinter as tk
from tkinter import filedialog as fd

root = tk.Tk()
root.title("Редактор")
t = tk.Text(root, wrap="word", undo=True)
s = tk.Scrollbar(root, command=t.yview)
t.config(yscrollcommand=s.set)
t.pack(side="left", fill="both", expand=True)
s.pack(side="right", fill="y")

def o():
    p = fd.askopenfilename()
    if p:
        t.delete(1.0, "end")
        t.insert(1.0, open(p, encoding="utf-8").read())

def w():
    p = fd.asksaveasfilename(defaultextension=".txt")
    if p: open(p, "w", encoding="utf-8").write(t.get(1.0, "end"))

m = tk.Menu(root)
f = tk.Menu(m, tearoff=0)
f.add_command(label="Открыть", command=o)
f.add_command(label="Сохранить", command=w)
f.add_separator()
f.add_command(label="Выход", command=root.quit)
m.add_cascade(label="Файл", menu=f)
root.config(menu=m)

root.bind("<Control-o>", lambda e: o())
root.bind("<Control-s>", lambda e: w())

root.mainloop()